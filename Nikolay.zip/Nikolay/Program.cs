﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nikolay;


class Program
{
    // Основной класс служит для взаимодйствия с пользователем
    static BusinessLogic logic;
    //Печатаем меню для выбора пользователем
    static void PrintMenu()
    {
        Console.WriteLine("Выберите необходимое действие:");
        Console.WriteLine("1) Добавить запись");
        Console.WriteLine("2) Просмотреть записи");
        Console.WriteLine("3) Изменить запись");
        Console.WriteLine("4) Удалить запись");
        Console.WriteLine("5) Выход");
        Console.Write("->");
    }
    //Выводит все сохраненные записи
    static void PrintList()
    {
        List<RouteRecord> list = logic.GetList();

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Список точек маршрута:");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("-----------------------------------------------------------------");
        foreach (RouteRecord record in list)
        {
            Console.WriteLine($"{record.wayTravel}: {record.id}) {record.address} - {record.events} - c {record.dateIn.ToString("yy'/'MM'/'dd")} по {record.dateOut.ToString("yy'/'MM'/'dd")} ");
            Console.WriteLine("-----------------------------------------------------------------");
        }
        Console.ForegroundColor= ConsoleColor.White;

    }
    //Добавляет запись
    static void AddRecord(int id = 0)
    {
        RouteRecord record = null;

        Console.WriteLine("Выберите способ передвижения:");
        Console.WriteLine("1) На машине");
        Console.WriteLine("2) На автобусе");
        string recordType = Console.ReadLine();

        try
        {
            Console.Write("Введите адрес маршрута: ");
            string address = Console.ReadLine();

            Console.Write("Введите мероприятия, через ;: ");
            string events = Console.ReadLine();

            Console.Write("Введите дату прибытия(дд/мм/гг): ");
            DateOnly dateIn = DateOnly.Parse(Console.ReadLine());

            Console.Write("Введите дату(дд/мм/гг): ");
            DateOnly dateOut = DateOnly.Parse(Console.ReadLine());

            switch (recordType)
            {
                case "1":
                    Console.Write("Введите необходимое кол-во бензина: ");
                    byte amountGasoline = byte.Parse(Console.ReadLine());
                    record = new CarRouteRecord(id, address, events, amountGasoline, dateIn, dateOut);
                    break;
                case "2":
                    Console.Write("Введите стоимость билета: ");
                    float price = float.Parse(Console.ReadLine());
                    record = new BusRouteRecord(id, address, events,price, dateIn,dateOut);
                    break;
            }
            if (logic.Save(record) is null)
            {
                Console.WriteLine("Данные были введены некорректно");
            }
            else
                Console.WriteLine("Запись была успешно добавлена");
        }
        catch (Exception)
        {
            Console.Clear();
            Console.WriteLine("Вы ввели некорректные данные, повторите ввод.");
            AddRecord();
        }


    }
    ///Удаляет запись
    static void DeleteRecord()
    {
        Console.WriteLine("Введите номер записи, которую хотите удалить:");
        int id = int.Parse(Console.ReadLine());
        if (logic.Delete(id) == true)
            Console.WriteLine("Удаление прошло успешно!!!");
        else
            Console.WriteLine("Удалить запись не удалось, попробуйте позже");

    }

    static void GetRecord()
    {
        Console.WriteLine("Введите номер записи, которую хотите получить:");
        int id = int.Parse(Console.ReadLine());
        RouteRecord record = logic.GetOne(id);
        if (record is null)
            Console.WriteLine("Запись с таким идентификатором не найдена");
        else
            Console.WriteLine($"{record.wayTravel}: {record.id} {record.address} - {record.events} - {record.dateIn.ToString("yy'/'MM'/'dd")}/{record.dateOut.ToString("yy'/'MM'/'dd")} ");

    }
    //Изменяет запись
    static void ChangeRecord()
    {
        Console.WriteLine("Введите номер записи, которую хотите изменить: ");
        int id = int.Parse(Console.ReadLine());
        if (logic.GetOne(id) is null)
            Console.WriteLine("Записи с таким идентификатором не найдена");
        else
        {
            logic.Save(logic.GetOne(id));
            AddRecord(id);
            Console.WriteLine($"Запись с номером {id}  успешно изменена!!!");
        }
    }


    static void Main()
    {
        logic = new BusinessLogic(new MemoryDataSource());
        bool exit = true;

        while (exit)
        {
            PrintMenu();
            string command = Console.ReadLine();
            switch (command)
            {
                case "1":
                    AddRecord();
                    break;
                case "2":
                    PrintList();
                    break;
                case "3":
                    ChangeRecord();
                    break;
                case "4":
                    DeleteRecord();
                    break;
                case "5":
                    exit = false;
                    break;
            }
        }


    }
}

//-------------------------------------------------------------------




