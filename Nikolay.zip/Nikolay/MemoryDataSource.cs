﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nikolay
{
    // Реализация различных методов для работы с записями
    public class MemoryDataSource : IDataSource
    {
        private List<RouteRecord> records = new List<RouteRecord>();
        static int count = 1; // счетчик для создания id

        public RouteRecord Save(RouteRecord record)
        {
            if (record.id == 0)
            {
                record.id = count;
                records.Add(record);
                count++;
                return record;
            }
            else
            {
                for (int i = 0; i < records.Count; i++)
                {
                    if (records[i].id == record.id)
                    {
                        records[i] = record;
                        return record;
                    }
                }
            }
            return record;
        }

        public RouteRecord Get(int id)
        {
            foreach (var item in records)
            {
                if (item.id == id)
                    return item;
            }
            return null;
        }

        public bool Delete(int id)
        {
            foreach (var item in records)
            {
                if (item.id == id)
                {
                    records.Remove(item);
                    return true;
                }
            }
            return false;
        }

        public List<RouteRecord> GetAll()
        {
            return records;
        }
    }
}
