﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nikolay
{
    // Логика для хранения данных 
    public interface IDataSource
    {
        RouteRecord Save(RouteRecord record);
        RouteRecord Get(int id);
        bool Delete(int id);
        List<RouteRecord> GetAll();
    }
}
