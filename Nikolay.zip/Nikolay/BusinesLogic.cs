﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nikolay
{
    //Класс бизнес-логики

    public class BusinessLogic
    {
        private IDataSource dataSource;

        public BusinessLogic(IDataSource source)
        {
            dataSource = source;
        }
        // Получение всех записей в отсортированном списке
        public List<RouteRecord> GetList()
        {
            List<RouteRecord> list = dataSource.GetAll().OrderBy(n => n.dateIn).ThenBy(n => n.address).ToList(); // Сортирует массив по дате и адрессу

            //*********
            return list;
        }

        // Получение одной записи
        public RouteRecord GetOne(int id)
        {
            return dataSource.Get(id);
        }

        // Удаление записи
        public bool Delete(int id)
        {
            return dataSource.Delete(id);
        }

        // Сохранение или обновление записи
        public RouteRecord Save(RouteRecord record)
        {
            if (record.events.Split(";").Length == 0 || record.address == "")
                return null;
            return dataSource.Save(record);
        }
    }
}
