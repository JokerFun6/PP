﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nikolay
{
    // Классы для представления основной записи
    abstract public class RouteRecord
    {
        public string wayTravel = "Travel";
        public int id;
        public string address;
        public string events;
        public DateOnly dateIn;
        public DateOnly dateOut;
    }

    // Класс Путешествия на машине
    class CarRouteRecord : RouteRecord
    {
        public byte amountGasoline; // кол-во бензина, необходимое для того чтобы добраться

        public CarRouteRecord(int id, string address, string events, byte amountGasoline, DateOnly cost, DateOnly date)
        {
            this.id = id;
            wayTravel = "Передвижение на машине";
            this.address = address;
            this.events = events;
            this.amountGasoline = amountGasoline;
            this.dateIn = cost;
            this.dateOut = date;
        }
    }
    // Класс для проезда на автобусе
    class BusRouteRecord : RouteRecord
    {
        public float ticketPrice; // Стоимость билета
        public BusRouteRecord(int id, string address, string events, float price, DateOnly dateIn, DateOnly dateOut)
        {
            this.id = id;
            wayTravel = "Передвижение на автобусе";
            this.address = address;
            this.events = events;
            this.ticketPrice = price;
            this.dateIn = dateIn;
            this.dateOut = dateOut;
        }
    }
}
